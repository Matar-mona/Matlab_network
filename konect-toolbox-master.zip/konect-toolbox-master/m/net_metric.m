 consts = konect_consts();
    

%%A = full(sparse(At(:,1), At(:,2), 1, n, n));
%%Gini_coef = konect_statistic_gini(A, consts.SYM, consts.UNWEIGHTED )
%%konect_print_bitmap(A, consts.SYM, consts.UNWEIGHTED );
%%diam_90 =konect_statistic_diameff90(A,consts.SYM, consts.UNWEIGHTED);
%%diam_50 =konect_statistic_diameff50(A,consts.SYM, consts.UNWEIGHTED);
%diam =konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
%path_part = 'C:\Users\mmata\Desktop\Data_csv\Time_stamps\';
%path_part = 'D:\mm_thesis\Data_csv\time_stamps\';
%path_part = 'D:\mm_thesis\D_csv\Time_stamps_Inh\';
%path_part = 'D:\mm_thesis\D_csv\Time_stamps_Coll\';
%path_part = 'D:\mm_thesis\SIG_Konect\';
%path_part = 'D:\mm_thesis\Software_graphs\SIG_Konect\'
%path_part = 'D:\mm_thesis\d_graph_Konect\CDot\'
%path_part = 'D:\mm_thesis\d_graph_Konect\CollDot\'
%path_part = 'D:\mm_thesis\d_graph_Konect\CollDot\'
path_part = 'D:\mm_thesis\Software_graphs\D_graph\Time_stamps\Time_stamps_CDot\';

%path_part = 'D:\mm_thesis\Software_graphs\D_graph\Time_stamps\Time_stamps_CollDot\';
%path_part = 'D:\mm_thesis\Software_graphs\D_graph\Hadoop_tstmp\Call\'
%path_part = 'D:\mm_thesis\Software_graphs\D_graph\Hadoop_tstmp\Collab\'
%path_part = 'D:\mm_thesis\Software_graphs\D_graph\Hadoop_tstmp\Inh\'




Fil = dir(path_part);


for k = 3:length(Fil)
%k =3; 
filenames = Fil(k).name;
%%disp(filenames)
path_file= strcat(path_part,filenames,'\');
dir_path = dir(path_file) ;
    %%disp(path_file);
X = genvarname(filenames);
i = 1;
%%disp(length(dir_path));
m_rows = length(dir_path) - 2;
%%disp(m_rows) ;
mm = zeros(m_rows,10);
%eval([X ' =mm']);

    for l = 3:length(dir_path)
        %disp('i');
        %disp(i)
%l = 3;
       % for the D_CSV 
       % tt = strsplit((dir_path(l).name ),'.');
       % tts = str2double(tt{1});
        
       % for the SIG
       
        %tt = strsplit((dir_path(l).name ),'__');
        tt = strsplit((dir_path(l).name ),'.');
        disp(tt)
        disp (dir_path(l).name );
        %tl = strsplit(tt{1},'_');
        %disp(tl)
        
        tts = str2double(tt(1))
        
       
        
        %tts = str2double(tt(1));
      
        %tts = tt(1);
        %disp(class(tt))
        disp('tts')
        disp(tts);
        %disp(tt(1))
    %%disp (dir_path(l).name )
        f_p = strcat(path_file,dir_path(l).name);

        f_path = dir(f_p);
        %%disp(f_path);
        At = load(f_p);
        new_A = get_AT(At);
       %%disp(new_A)
        tl =  get_values(new_A);
    
    %(shos(tl));
        mm(i,1) = tts;
        mm(i,2) = l
        %mm(i,2) = tt(1);
%         %disp('size')
%         disp(size(tl))
         %disp('tl'); disp(tl);
%         
        mm(i,3:10) = transpose(tl);
    %transpose(get_values(new_A));
      
%tl = table(v_squares, v_diam, stars, two_stars, three_stars, four_stars,P);
       % tt = [v_squares, v_diam, stars,two_stars, three_stars, four_stars,P];
        %var_1(:,i) = tt;
        i = i+1;
       
       %%disp (v_diam);
    end
disp('eval')
eval([X ' =mm']);
%disp(f_path)
%writematrix(eval([X ' =mm']),filename)
end
    
   


%csvwrite('D:\mm_thesis\D_csv\time_stamps\accumulot_mat.csv',accumulo)
% dlmwrite('D:\mm_thesis\D_csv\time_stamps\Ivyt_mat.csv',IVY,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\SIG_Konect\Ivyt_mat.csv',IVY,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\D_graph_Komect_metrics\Ivy_call_mat.csv',Ivy,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\D_graph\D_matlab\Cassandra_mat.csv',Cassandra,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\D_graph\D_matlab\Chukwa_mat.csv',Chukwa,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\D_graph\D_matlab\http_mat.csv',http,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\Software_graphs\D_graph\D_matlab\Coll_mat\Jena_Coll_mat.csv',Jena,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\Software_graphs\D_graph\D_matlab\Call_mat\Jena_Call_mat.csv',Jena,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\Software_graphs\D_graph\D_matlab\Inh_mat\Jena_Inh_mat.csv',Jena,'delimiter',',','precision',12)
%dlmwrite('D:\mm_thesis\Software_graphs\D_graph\D_matlab\_mat\Hadoop_mat.csv',hadoop,'delimiter',',','precision',12)


    %%disp(dir_path)
    %%disp(Fil(k).name)
function new_A = get_AT(At)
    %At = load(file_path);
    nodes = cat(1,At(:,1),At(:,2));
    C = unique(nodes,'sorted') ;
    
   % nodes_map = (1:length(C));
    for i=1:length(At)
        for j =1:2
            %%disp('original');
            %%disp(At(i,j));
            r1 = find(C== At(i,j));
            %%disp('maps');
            %%disp(r1);
            new_A(i,j)= r1;
        end
    end
end

%function [v_squares, v_diam, stars,two_stars, three_stars, four_stars,P] = get_(new_A)
function res = get_values(new_A)
    consts = konect_consts();
    n = max(max(new_A));
  
    A = full(sparse(new_A(:,1), new_A(:,2), 1, n, n));
    
    v_squares = konect_statistic_squares(A, consts.SYM, consts.UNWEIGHTED); 
    %disp(v_squares);
    v_diam = konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
    stars =  konect_statistic_triangles(A, consts.SYM, consts.UNWEIGHTED);
    two_stars =  konect_statistic_twostars(A, consts.SYM, consts.UNWEIGHTED) ;
    three_stars =  konect_statistic_threestars(A, consts.SYM, consts.UNWEIGHTED );
    four_stars =  konect_statistic_fourstars(A, consts.SYM, consts.UNWEIGHTED );
    %edgs =  konect_statistic_volume(A, consts.SYM, consts.UNWEIGHTED );
    %rad = konect_statistic_radius(A, consts.SYM, consts.UNWEIGHTED );
    P = konect_statistic_power(A, consts.SYM, consts.UNWEIGHTED );
   % P2 = konect_statistic_power2(A, consts.SYM, consts.UNWEIGHTED );

    %diam =konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
  %  disp('P2'); disp(P2);
%     disp('squares');
%     disp(v_squares);
%     disp('diam');disp(v_diam);
%     disp('stars');disp(stars);
 %    disp('2-stars');disp(two  _stars);
%     
%    disp('3_stars');disp(three_stars);
%     disp('4_atars');disp(four_stars);
%     disp('P');disp(P);
%     disp('end');
    res = [v_squares; v_diam; stars; two_stars;three_stars;four_stars; P];
    
end