 consts = konect_consts();
    

%%A = full(sparse(At(:,1), At(:,2), 1, n, n));
%%Gini_coef = konect_statistic_gini(A, consts.SYM, consts.UNWEIGHTED )
%%konect_print_bitmap(A, consts.SYM, consts.UNWEIGHTED );
%%diam_90 =konect_statistic_diameff90(A,consts.SYM, consts.UNWEIGHTED);
%%diam_50 =konect_statistic_diameff50(A,consts.SYM, consts.UNWEIGHTED);
%diam =konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
%path_part = 'C:\Users\mmata\Desktop\Data_csv\Time_stamps\';
%path_part = 'D:\mm_thesis\Data_csv\time_stamps\',
%path_part = 'D:\mm_thesis\DSIG_Konect\';
path_part = 'D:\mm_thesis\D_graph\Time_stamps\Time_stamps_Call\';
Fil = dir(path_part);


for k = 3:length(Fil)
    filenames = Fil(k).name;
    disp(filenames)
    path_file= strcat(path_part,filenames,'\');
    dir_path = dir(path_file) ;
    disp(dir_path);
    X = genvarname(filenames);
    i = 1;
    m_rows = length(dir_path) - 2;
    mm = zeros(m_rows,9);
    for l = 3:length(dir_path)
        tt = strsplit((dir_path(l).name ),'.');
        disp(tt);
        disp (dir_path(l).name );
        tts = str2double(tt(1));
        f_p = strcat(path_file,dir_path(l).name);      
        f_path = dir(f_p);
        %disp(f_path);
        At = load(f_p);
        new_A = get_AT(At);
        tl =  get_values(new_A);
        mm(i,1) = tts;
        mm(i,2:9) = transpose(tl);
       %disp(new_A)
        %[v_squares, v_diam, stars,two_stars, three_stars, four_stars,P] = get_values(new_A) 
        i = i+1;
       
       
    end
    eval([X ' =mm']);
end
    
   
    %disp(dir_path)
    %disp(Fil(k).name)
function new_A = get_AT(At)
    %At = load(file_path);
    nodes = cat(1,At(:,1),At(:,2));
    C = unique(nodes,'sorted') ;
   % nodes_map = (1:length(C));
    for i=1:length(At)
        for j =1:2
            %disp('original');
            %disp(At(i,j));
            r1 = find(C== At(i,j));
            %disp('maps');
            %disp(r1);
            new_A(i,j)= r1;
        end
    end
end

%function [v_squares, v_diam, stars,two_stars, three_stars, four_stars,P] = get_(new_A)
function res = get_values(new_A)
    consts = konect_consts();
    n = max(max(new_A));

    A = full(sparse(new_A(:,1), new_A(:,2), 1, n, n));
    v_squares = konect_statistic_squares(A, consts.SYM, consts.UNWEIGHTED); 
    v_diam = konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
    stars =  konect_statistic_triangles(A, consts.SYM, consts.UNWEIGHTED);
    two_stars =  konect_statistic_twostars(A, consts.SYM, consts.UNWEIGHTED) ;
    three_stars =  konect_statistic_threestars(A, consts.SYM, consts.UNWEIGHTED );
    four_stars =  konect_statistic_fourstars(A, consts.SYM, consts.UNWEIGHTED );
    %edgs =  konect_statistic_volume(A, consts.SYM, consts.UNWEIGHTED );
    %rad = konect_statistic_radius(A, consts.SYM, consts.UNWEIGHTED );
    P = konect_statistic_power(A, consts.SYM, consts.UNWEIGHTED );

    %diam =konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
    res = [v_squares; v_diam; stars; two_stars;three_stars;four_stars; P];
end