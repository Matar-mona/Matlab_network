%
% The "format" as a statistic, i.e., the numerical ID of the format.
%

function values = konect_statistic_format(A, format, weights)

  values(1) = format;
  
