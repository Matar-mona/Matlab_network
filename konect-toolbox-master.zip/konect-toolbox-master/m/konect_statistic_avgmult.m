%
% Average multiplicity.
%
% GROUP:  multi
%

function values = konect_statistic_avgmult(A, format, weights)

assert(0);  % Not implemented
