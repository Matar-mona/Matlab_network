%
% The preferential attachment exponent.  This statistic depends on
% the temporal evolution of a network and thus cannot be computed in
% this file.  This file only exists to document the TIME group. 
%
% GROUP:  time
%

error('Cannot be computed in this way');
