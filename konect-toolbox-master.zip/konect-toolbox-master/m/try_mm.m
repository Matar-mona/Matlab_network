for i = 1 : length(names)
    name = names{i}
    At = Ats.(name);
    count = counts.(name); 

    n = max(max(At)); 
     
    fprintf(' max')
    disp(n)
    A = full(sparse(At(:,1), At(:,2), 1, n, n)); 
    fprintf('full sparse')
    disp(A)
    

    values = konect_statistic_squares(A, consts.SYM, consts.UNWEIGHTED); 
    v_diam = konect_statistic_diameter(A,consts.SYM, consts.UNWEIGHTED);
    diam_90 =konect_statistic_diameff90(A,consts.SYM, consts.UNWEIGHTED);
    diam_50 =konect_statistic_diameff50(A,consts.SYM, consts.UNWEIGHTED);
    diam =konect_statistic_diam(A,consts.SYM, consts.UNWEIGHTED);
    
    fprintf('values')
    disp(values)
    disp(v_diam)
    disp(diam_90)
    disp(diam_50)
    disp(diam)
    assert(values(1) == count); 
end
consts = konect_consts();
kart = load('C:\Users\mmata\Desktop\karate.txt');
%Fil = dir('C:\Users\mmata\Desktop\Data_csv\Time_stamps\')
Fik_dir = 'D:\mm_thesis\Data_csv\time_stamps\';
for k = 1:length(Fil)
    filenames = Fil(k).name
    disp(Fil(k).name)
end