% GROUP:  square
