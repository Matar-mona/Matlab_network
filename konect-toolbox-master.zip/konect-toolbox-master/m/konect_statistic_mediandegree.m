%
% The median degree.
%
% values
%	[1] 	Median degree
%	[2]	Left median degree (BIP)
%	[3]	Right median degree (BIP)
%	[4]	Median outdegree (ASYM)
%	[5]	Median indegree (ASYM)
%
% GROUP+2:  bip
% GROUP+3:  bip
% GROUP+4:  asym
% GROUP+5:  asym
%

error % Not implemented in Matlab; only in C in konect-analysis/



