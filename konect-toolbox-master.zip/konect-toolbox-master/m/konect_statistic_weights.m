%
% The "weights" as a statistic, i.e., the numerical ID of the weights.
%

function values = konect_statistic_weights(A, format, weights)

  values(1) = weights;
  
