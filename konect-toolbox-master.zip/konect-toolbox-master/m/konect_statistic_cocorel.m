%
% Compute the size of the relative largest connected component [cocorel].
%
% This is the same as [coco+2]. 
% 

