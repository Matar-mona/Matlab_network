
% GROUP:  square

